<?php
namespace Models;
use Illuminate\Database\Eloquent\Model;
class primary_subject extends Model
{
   /**
    * The database table used by the model.
    *
    * @var string
    */
    public $table = "primary_subject";
  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */

 }

 ?>