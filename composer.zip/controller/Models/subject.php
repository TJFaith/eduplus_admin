<?php
namespace Models;
use Illuminate\Database\Eloquent\Model;
class subject extends Model
{
   /**
    * The database table used by the model.
    *
    * @var string
    */
    public $table = "subjects";
  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */

 }

 ?>