<?php
namespace Models;
use Illuminate\Database\Eloquent\Model;
class certification extends Model
{
   /**
    * The database table used by the model.
    *
    * @var string
    */
    public $table = "certification";
  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */

 }

 ?>