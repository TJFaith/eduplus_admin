<?php
namespace Models;
use Illuminate\Database\Eloquent\Model;
class user extends Model
{
   /**
    * The database table used by the model.
    *
    * @var string
    */
    public $table = "users";
  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */

 }

 ?>